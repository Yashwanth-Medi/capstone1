package com.infinite.capstone.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ADMIN")
public class Admin {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "Admin_Id")
	    private int adminId;

	    @Column(name = "Username", unique = true)
	    private String username;

	    @Column(name = "Password")
	    private String password;

	  

	    // Constructors
	    public Admin() {
	       
	    }
}