package com.infinite.capstone.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.capstone.pojo.OrderList;
import com.infinite.capstone.repository.OrderListRepository;

@Service

public class OrderListService implements IOrderListService {
	@Autowired
	OrderListRepository OrderRepository;

	@Override
	public void save(OrderList order) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public OrderList findById(int orderId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<OrderList> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<OrderList> findByUserId(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(OrderList order) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int orderId) {
		// TODO Auto-generated method stub
		
	}
	

}
