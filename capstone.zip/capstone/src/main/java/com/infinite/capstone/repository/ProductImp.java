package com.infinite.capstone.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.infinite.capstone.pojo.Product;

@Repository
public class ProductImp  implements ProductRepository{

	@Override
	public void save(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Product findById(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> findByVendorId(int vendorId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int productId) {
		// TODO Auto-generated method stub
		
	}

}
