package com.infinite.capstone.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.infinite.capstone.pojo.Customer;
import com.infinite.capstone.pojo.Items;

@Repository
@EnableAsync(proxyTargetClass = true)
@EnableCaching(proxyTargetClass = true)
@EnableTransactionManagement
public class ItemsImpl implements ItemsRepository{

	private static final Logger logger = Logger.getLogger(CustomerImpl.class);
	private SessionFactory sesfactory;
	public void setSesfactory(SessionFactory sesfactory) {
		this.sesfactory = sesfactory;
	}
	@Override
	@Transactional
	public Items save(Items item) {
		// TODO Auto-generated method stub
		Session session = this.sesfactory.getCurrentSession();
		session.save(item);
		return item;
		
	}

	
	@Transactional
	public List<Items> findById(int order_List) {
		// TODO Auto-generated method stub
		Session session = this.sesfactory.getCurrentSession();
		Query query=session.createQuery("FROM capstone WHERE order_List= :order_List AND ");
		
		query.setParameter("order_List", order_List);
		List<Items> ls = query.list();
		
		return ls;
		
	}

	@Override
	@Transactional
	public List<Items> findAll() {
		// TODO Auto-generated method stub
		Session session = this.sesfactory.getCurrentSession();
		Query query=session.createQuery("FROM capstone  ");
		List<Items> ls = query.list();
		
		return ls;
	}
	/*
	 * @Override
	 * 
	 * @Transactional public Items update(Items item) { // TODO Auto-generated
	 * method stub
	 * 
	 * return null; }
	 * 
	 * @Override
	 * 
	 * @Transactional public Items delete(int itemId) { // TODO Auto-generated
	 * method stub return null; }
	 */

	
}
