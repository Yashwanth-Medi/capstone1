package com.infinite.capstone.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.capstone.pojo.Product;
import com.infinite.capstone.repository.ProductRepository;

@Service
public class ProductService implements IProductService {
	@Autowired
	ProductRepository productRepository;

	@Override
	public void save(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Product findById(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> findByVendorId(int vendorId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int productId) {
		// TODO Auto-generated method stub
		
	}
	

}
