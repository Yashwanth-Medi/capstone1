package com.infinite.capstone.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.infinite.capstone.pojo.Product;



public interface ProductRepository {
	
	 void save(Product product);

	    Product findById(int productId);

	    List<Product> findAll();

	    List<Product> findByVendorId(int vendorId);

	    void update(Product product);

	    void delete(int productId);

}
