package com.infinite.capstone.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.capstone.pojo.Items;
import com.infinite.capstone.repository.ItemsRepository;


@Service
public class ItemService implements IItemsService {

	@Autowired
	ItemsRepository itemRepository ;

	@Override
	public Items save(Items item) {
		// TODO Auto-generated method stub
		  return null;
	}

	@Override
	public List<Items> findById(int itemId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Items> findAll() {
		// TODO Auto-generated method stub
		return null ;
	}

	

   

}
