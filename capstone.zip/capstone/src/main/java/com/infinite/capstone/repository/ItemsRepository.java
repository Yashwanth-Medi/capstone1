package com.infinite.capstone.repository;



import java.util.List;

import org.springframework.stereotype.Repository;

import com.infinite.capstone.pojo.Items;

public interface ItemsRepository {

	public Items save(Items item);

	public List<Items> findById(int itemId);

	public List<Items> findAll();
	/*
	 * public Items update(Items item);
	 * 
	 * public Items delete(int itemId);
	 */

}
