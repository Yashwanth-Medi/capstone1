package com.infinite.capstone.services;

import java.util.List;

import com.infinite.capstone.pojo.Admin;

public interface IAdminService {


	public List<Admin> findAll();
	public Admin save(Admin Admin);
	

}
