package com.infinite.capstone.services;


import java.util.List;

import org.springframework.stereotype.Repository;

import com.infinite.capstone.pojo.Items;


public interface IItemsService {
	
	public Items save(Items item);

	public List<Items> findById(int itemId);

	public List<Items> findAll();

}
