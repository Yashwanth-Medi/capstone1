package com.infinite.capstone.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infinite.capstone.pojo.Customer;
import com.infinite.capstone.repository.CustomerRepository;
import com.infinite.capstone.services.CustomerService;
import com.infinite.capstone.services.ICustomer;




@RestController
@CrossOrigin("http://localhost:3000/")
public class CustomerController {
	
	@Autowired
CustomerService cserviceimpl;

	
	@RequestMapping(value = "/register", method = RequestMethod.POST, headers = "Accept=application/json")
	public ResponseEntity<String> addCustomer(@RequestBody Customer Login) {
		try {
			cserviceimpl.addCustomer(Login);
            return ResponseEntity.ok("Registration successful");

		}
		catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Registration failed");
        }
	}
	
	@RequestMapping(value="/login")
	public ResponseEntity<String> loginUser(@RequestBody Customer login) {
        String email = login.getEmail();
        String password = login.getPassword();
 
        Customer validateuser = cserviceimpl.validateUser(email, password);
        if(validateuser!=null) {
        	//returns status code 200
        	return ResponseEntity.ok("Login successfull");
        }
        else {
        	//returns status code 401 unauthorized
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("invalid credintials");

        }
       
	}


}
