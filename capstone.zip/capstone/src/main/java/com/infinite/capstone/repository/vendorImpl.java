package com.infinite.capstone.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.infinite.capstone.pojo.Vendor;

@Repository
@EnableAsync(proxyTargetClass = true)
@EnableCaching(proxyTargetClass = true)
@EnableTransactionManagement
public class vendorImpl  implements VendorRepository{
	
	private static final Logger logger = Logger.getLogger(CustomerImpl.class);
	private SessionFactory sesfactory;
	public void setSesfactory(SessionFactory sesfactory) {
		this.sesfactory = sesfactory;
	}
	@Override
	public VendorRepository AddVendor(VendorRepository vendor) {
		// TODO Auto-generated method stub
		Session session = this.sesfactory.getCurrentSession();
		session.save(vendor);
		return vendor;
	
	}
	@Override
	public VendorRepository findById(int vendorId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

	
	}

	

