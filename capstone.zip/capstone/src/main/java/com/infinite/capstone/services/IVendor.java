package com.infinite.capstone.services;

import com.infinite.capstone.pojo.Vendor;

public interface IVendor {
	public Vendor AddVendor(Vendor vendor);

	public  Vendor findById(int vendorId);
}
