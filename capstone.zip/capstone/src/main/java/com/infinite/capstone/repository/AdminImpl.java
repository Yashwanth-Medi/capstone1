package com.infinite.capstone.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.infinite.capstone.pojo.Admin;

@Repository
public class AdminImpl implements AdminRepository {

	@Override
	public List<Admin> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Admin save(Admin Admin) {
		// TODO Auto-generated method stub
		return null;
	}

}
