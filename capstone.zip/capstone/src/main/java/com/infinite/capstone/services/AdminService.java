package com.infinite.capstone.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.capstone.pojo.Admin;
import com.infinite.capstone.repository.AdminRepository;

@Service
public class AdminService {

	@Autowired
	AdminRepository adminRepository;
	
	
	//CREATE
		public  Admin createAdmin(Admin admin) {
		    return adminRepository.save(admin);
		}
	 
		//READ
		public List< Admin> getAdmins() {
		    return adminRepository.findAll();
		}
		
	}

	

