package com.infinite.capstone.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.infinite.capstone.pojo.OrderList;

@Repository
public class OrderListImpl implements OrderListRepository {

	@Override
	public void save(OrderList order) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public OrderList findById(int orderId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<OrderList> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<OrderList> findByUserId(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(OrderList order) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int orderId) {
		// TODO Auto-generated method stub
		
	}

}
