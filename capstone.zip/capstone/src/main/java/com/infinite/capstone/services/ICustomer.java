package com.infinite.capstone.services;

import com.infinite.capstone.pojo.Customer;

public interface ICustomer {
	
public void addCustomer(Customer customerLogin);
	
	public Customer validateUser(String email, String password);

}
