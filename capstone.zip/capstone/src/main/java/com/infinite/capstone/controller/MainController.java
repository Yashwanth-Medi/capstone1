package com.infinite.capstone.controller;

public class MainController {
	
	

}
