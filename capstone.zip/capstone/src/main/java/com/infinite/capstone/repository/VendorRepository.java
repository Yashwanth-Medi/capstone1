package com.infinite.capstone.repository;

import java.util.List;


import org.springframework.stereotype.Repository;

import com.infinite.capstone.pojo.Vendor;



public interface VendorRepository {
	
	public VendorRepository AddVendor(VendorRepository vendor);

	public  VendorRepository findById(int vendorId);
	/*
	 * List<Vendor> findAll();
	 * 
	 * Vendor findByUserId(int userId);
	 * 
	 * void update(Vendor vendor);
	 * 
	 * void delete(int vendorId);
	 */

}
