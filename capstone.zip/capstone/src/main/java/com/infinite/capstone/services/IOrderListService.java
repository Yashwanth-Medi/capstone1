package com.infinite.capstone.services;

import java.util.List;


import org.springframework.stereotype.Repository;

import com.infinite.capstone.pojo.OrderList;


public interface IOrderListService  {
	
	 void save(OrderList order);

	    OrderList findById(int orderId);

	    List<OrderList> findAll();

	    List<OrderList> findByUserId(int userId);

	    void update(OrderList order);

	    void delete(int orderId);

}
