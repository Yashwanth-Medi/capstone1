package com.infinite.capstone.repository;



import java.util.List;

import org.springframework.stereotype.Repository;

import com.infinite.capstone.pojo.Admin;



public interface AdminRepository  {
	

	public List<Admin> findAll();
	public Admin save(Admin Admin);
	

	
	
	
	

}
