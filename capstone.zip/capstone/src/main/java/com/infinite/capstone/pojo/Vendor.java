package com.infinite.capstone.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "VENDOR")
public class Vendor {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "Product_Id")
	    private int productId;
	    
	    @Column(name = "User_Id")
	    private int userId;

	    @Column(name = "First_name")
	    private String firstName;

	    @Column(name = "Last_name")
	    private String lastName;

	    @Column(name = "Email")
	    private String Email;

	    @Column(name = "License")
	    private String license;

	    @Column(name = "Certificate")
	    private String certificate;

	    @Column(name = "Phno")
	    private String phno;

	    @Column(name = "Password")
	    private String password;

	    @Column(name = "Confirm_Password")
	    private String confirmPassword;


	public Vendor(){
		
	}


	}