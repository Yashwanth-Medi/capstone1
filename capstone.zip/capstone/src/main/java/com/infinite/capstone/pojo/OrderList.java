package com.infinite.capstone.pojo;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ORDERLIST")
public class OrderList {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Order_Id")
    private int order_Id;

  
    @Column(name = "User_Id")
    private int User_Id ;

    @Column(name = "Product_name")
    private String product_Name;

    @Column(name = "Product_Id")
    private int product_Id;

    @Column(name = "Price")
    private int price;

    @Column(name = "Quantity")
    private int quantity;

  

    // Constructors,
    public OrderList() {
    	
    }
	
}
