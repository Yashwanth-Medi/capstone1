package com.infinite.capstone.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.infinite.capstone.pojo.Customer;


public interface CustomerRepository {

	public Customer addCustomer(Customer customer);

	public Customer validateuser(String email, String password);
}
