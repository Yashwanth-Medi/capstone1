package com.infinite.capstone.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.capstone.pojo.Vendor;
import com.infinite.capstone.repository.VendorRepository;

@Service
public class VendorService implements IVendor {
	@Autowired
	VendorRepository vendorRepository;

	@Override
	public Vendor AddVendor(Vendor vendor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Vendor findById(int vendorId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	

}
