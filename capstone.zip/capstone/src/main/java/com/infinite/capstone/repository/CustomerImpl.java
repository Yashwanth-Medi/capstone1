package com.infinite.capstone.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.infinite.capstone.pojo.Customer;

@Repository
@EnableAsync(proxyTargetClass = true)
@EnableCaching(proxyTargetClass = true)
@EnableTransactionManagement

public class CustomerImpl implements CustomerRepository{

	private static final Logger logger = Logger.getLogger(CustomerImpl.class);
	private SessionFactory sesfactory;
	public void setSesfactory(SessionFactory sesfactory) {
		this.sesfactory = sesfactory;
	}
	
	
	@Transactional
	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		Session session = this.sesfactory.getCurrentSession();
		session.save(customer);
		return customer;
	
	}

	@Transactional
	public Customer validateuser(String email, String password) {
		// TODO Auto-generated method stub
		Session session = this.sesfactory.getCurrentSession();
		Query query=session.createQuery("FROM capstone WHERE email= :email AND password= :password");
		query.setParameter("email", email);
		query.setParameter("password", password);
		Customer validateuser=(Customer) query.uniqueResult();
		return validateuser;
		
	}


	
		
	}


